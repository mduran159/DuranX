using IdentityServer;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddIdentityServer()
                .AddInMemoryClients(Config.Clients)
                .AddInMemoryApiScopes(Config.ApiScopes)
                .AddDeveloperSigningCredential();

// Configurar Kestrel para usar el certificado
builder.WebHost.ConfigureKestrel(options =>
{
    options.ListenAnyIP(8080); // HTTP
    options.ListenAnyIP(8081, listenOptions =>
    {
        listenOptions.UseHttps("/root/.aspnet/https/duranx-https-certificate.pfx", "Sp1r4l123456789"); // Ruta y contrase�a del certificado
    }); // HTTPS
});

var app = builder.Build();

app.UseIdentityServer();

app.Run();
